<?php

	// how to use image from example 001
	echo '<img src="example_001_simple_png_output.php" />';