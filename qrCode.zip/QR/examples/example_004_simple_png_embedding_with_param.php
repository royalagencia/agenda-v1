<?php

	// how to use image from example 003 with custom param
	
	$ourParamId = 1234;
	
	echo '<img src="example_003_simple_png_output_param.php?id='.$ourParamId.'" />';
	