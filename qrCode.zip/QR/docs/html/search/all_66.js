var searchData=
[
  ['factory',['factory',['../class_q_rencode.html#a0cfc99f865cb401ee5f3492004a3c3ff',1,'QRencode']]]
];
