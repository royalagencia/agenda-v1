var searchData=
[
  ['canvas',['canvas',['../class_q_rcode.html#a036166ee2cabf2089f0d7744f0e5b7ab',1,'QRcode']]]
];
