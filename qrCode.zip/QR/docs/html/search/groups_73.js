var searchData=
[
  ['standard_20api_20core',['Standard API Core',['../group___core_group.html',1,'']]],
  ['standard_20api_20output',['Standard API Output',['../group___output_group.html',1,'']]]
];
