var searchData=
[
  ['raw',['raw',['../class_q_rcode.html#abab58ac89ce34bc4e1abe838fbc05ad2',1,'QRcode']]]
];
